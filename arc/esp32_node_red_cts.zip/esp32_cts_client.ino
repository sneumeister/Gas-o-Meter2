#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEScan.h>
#include <BLEClient.h>
#include <esp_sleep.h>
#include <time.h>

#define SERVICE_UUID        "00001805-0000-1000-8000-00805f9b34fb" // Current Time Service
#define CHARACTERISTIC_UUID "00002A2B-0000-1000-8000-00805f9b34fb" // Current Time Characteristic

RTC_DATA_ATTR int64_t nextWakeupOffset = 6 * 60 * 60; // 6 Stunden in Sekunden

void setup() {
  Serial.begin(115200);
  delay(1000);

  BLEDevice::init("");
  BLEScan* pBLEScan = BLEDevice::getScan();
  pBLEScan->setActiveScan(true);
  BLEScanResults foundDevices = pBLEScan->start(5);

  for (int i = 0; i < foundDevices.getCount(); i++) {
    BLEAdvertisedDevice device = foundDevices.getDevice(i);
    if (device.haveServiceUUID() && device.isAdvertisingService(BLEUUID(SERVICE_UUID))) {
      BLEClient*  pClient  = BLEDevice::createClient();
      pClient->connect(&device);

      BLERemoteService* pRemoteService = pClient->getService(BLEUUID(SERVICE_UUID));
      if (pRemoteService != nullptr) {
        BLERemoteCharacteristic* pRemoteCharacteristic = pRemoteService->getCharacteristic(BLEUUID(CHARACTERISTIC_UUID));
        if (pRemoteCharacteristic != nullptr) {
          std::string value = pRemoteCharacteristic->readValue();
          const uint8_t* data = (const uint8_t*)value.data();

          // CTS Format: [year_lsb, year_msb, month, day, hour, minute, second, day_of_week, fractions256, adjust_reason]
          struct tm timeinfo;
          timeinfo.tm_year = (data[0] | (data[1] << 8)) - 1900;
          timeinfo.tm_mon  = data[2] - 1;
          timeinfo.tm_mday = data[3];
          timeinfo.tm_hour = data[4];
          timeinfo.tm_min  = data[5];
          timeinfo.tm_sec  = data[6];
          timeinfo.tm_isdst = 0;

          time_t receivedTime = mktime(&timeinfo);
          Serial.printf("Received UTC time: %s", asctime(&timeinfo));

          // Berechne Offset zum nächsten 6h-Zeitpunkt
          int secondsSinceMidnight = timeinfo.tm_hour * 3600 + timeinfo.tm_min * 60 + timeinfo.tm_sec;
          int nextWake = ((secondsSinceMidnight / 21600) + 1) * 21600;
          nextWakeupOffset = nextWake - secondsSinceMidnight;
        }
      }
      pClient->disconnect();
      break;
    }
  }

  Serial.printf("Going to sleep for %lld seconds
", nextWakeupOffset);
  esp_sleep_enable_timer_wakeup(nextWakeupOffset * 1000000);
  esp_deep_sleep_start();
}

void loop() {
  // Nicht verwendet
}
