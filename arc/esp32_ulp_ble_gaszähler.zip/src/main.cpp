#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEScan.h>
#include <BLEClient.h>
#include <BLEServer.h>
#include <BLE2902.h>
#include <esp_sleep.h>
#include <driver/rtc_io.h>
#include "ulp_gas.h"

#define WAKE_GPIO GPIO_NUM_33
#define SERVICE_UUID_CTS "00001805-0000-1000-8000-00805f9b34fb"
#define CHARACTERISTIC_UUID_CTS "00002A2B-0000-1000-8000-00805f9b34fb"
#define SERVICE_UUID_GAS "12345678-1234-1234-1234-1234567890ab"
#define CHARACTERISTIC_UUID_GAS "2A6C" // Temperature characteristic reused for gas counter

RTC_DATA_ATTR uint32_t gas_counter = 0;
BLECharacteristic *gasCharacteristic;

void bleTask(void *pvParameters) {
  BLEDevice::init("ESP32_GasCounter");
  BLEScan* pBLEScan = BLEDevice::getScan();
  pBLEScan->setActiveScan(true);
  BLEScanResults foundDevices = pBLEScan->start(5);

  for (int i = 0; i < foundDevices.getCount(); i++) {
    BLEAdvertisedDevice device = foundDevices.getDevice(i);
    if (device.haveServiceUUID() && device.isAdvertisingService(BLEUUID(SERVICE_UUID_CTS))) {
      BLEClient* pClient = BLEDevice::createClient();
      pClient->connect(&device);

      BLERemoteService* pRemoteService = pClient->getService(BLEUUID(SERVICE_UUID_CTS));
      if (pRemoteService != nullptr) {
        BLERemoteCharacteristic* pRemoteCharacteristic = pRemoteService->getCharacteristic(BLEUUID(CHARACTERISTIC_UUID_CTS));
        if (pRemoteCharacteristic != nullptr) {
          std::string value = pRemoteCharacteristic->readValue();
          const uint8_t* data = (const uint8_t*)value.data();

          struct tm timeinfo;
          timeinfo.tm_year = (data[0] | (data[1] << 8)) - 1900;
          timeinfo.tm_mon  = data[2] - 1;
          timeinfo.tm_mday = data[3];
          timeinfo.tm_hour = data[4];
          timeinfo.tm_min  = data[5];
          timeinfo.tm_sec  = data[6];
          timeinfo.tm_isdst = 0;

          time_t receivedTime = mktime(&timeinfo);
          Serial.printf("Received UTC time: %s", asctime(&timeinfo));

          int secondsSinceMidnight = timeinfo.tm_hour * 3600 + timeinfo.tm_min * 60 + timeinfo.tm_sec;
          int nextWake = ((secondsSinceMidnight / 21600) + 1) * 21600;
          int nextWakeupOffset = nextWake - secondsSinceMidnight;

          BLEServer *pServer = BLEDevice::createServer();
          BLEService *pService = pServer->createService(SERVICE_UUID_GAS);
          gasCharacteristic = pService->createCharacteristic(
            CHARACTERISTIC_UUID_GAS,
            BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
          );
          gasCharacteristic->addDescriptor(new BLE2902());
          gasCharacteristic->setValue((uint32_t)gas_counter);
          pService->start();
          BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
          pAdvertising->addServiceUUID(SERVICE_UUID_GAS);
          pAdvertising->start();

          delay(5000); // Allow time for BLE transmission

          esp_sleep_enable_ext0_wakeup(WAKE_GPIO, 0);
          esp_sleep_enable_timer_wakeup(nextWakeupOffset * 1000000);
          esp_deep_sleep_start();
        }
      }
      pClient->disconnect();
      break;
    }
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  ulp_load_binary(0, (const uint8_t *)ulp_gas_bin_start, (ulp_gas_bin_end - ulp_gas_bin_start) / sizeof(uint32_t));
  ulp_gas_counter = gas_counter;
  ulp_run(0);

  xTaskCreate(bleTask, "BLE Task", 8192, NULL, 1, NULL);
}

void loop() {
}